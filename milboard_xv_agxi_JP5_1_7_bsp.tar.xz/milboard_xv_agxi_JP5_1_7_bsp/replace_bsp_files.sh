#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
        echo "Please run as root"
        echo "Quitting ..."
        exit 1
fi

# Replace base DTB file
mv tegra194-p2888-0008-p2822-0000.dtb Linux_for_Tegra/kernel/dtb/

# Replace kernel Image & nvgpu.ko
mv Image Linux_for_Tegra/kernel/
sudo mv nvgpu.ko Linux_for_Tegra/rootfs/usr/lib/modules/5.10.216-tegra/kernel/drivers/gpu/nvgpu/nvgpu.ko
sudo rm Linux_for_Tegra/rootfs/lib/modules/5.10.216-tegra/kernel/drivers/net/ethernet/microchip/lan743x.ko
sudo rm Linux_for_Tegra/rootfs/lib/modules/5.10.216-tegra/kernel/drivers/net/usb/cdc_mbim.ko
sudo rm Linux_for_Tegra/rootfs/lib/modules/5.10.216-tegra/kernel/drivers/usb/class/cdc-wdm.ko


echo "Done."

